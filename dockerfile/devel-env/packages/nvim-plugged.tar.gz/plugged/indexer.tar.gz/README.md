Vim-Indexer
===========

A Vim plugin that provides painless transparent tags generation and keeps tags up-to date.

For thorough discussion on advanced usage of Indexer + Vimprj, see the article
[Vim: convenient code navigation for your projects](http://dmitryfrank.com/articles/vim_project_code_navigation).

