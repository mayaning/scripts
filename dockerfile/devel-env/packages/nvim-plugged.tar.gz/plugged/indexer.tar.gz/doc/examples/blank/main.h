
#include "some_folder_1/some_header.h"

extern long my_global_long;
extern int  my_global_int;


