P4 syntax highlighting for vim
====

## About P4:
P4 is a declarative language for expressing how packets are processed by the pipeline of a network forwarding element such as a switch, NIC, router or network function appliance. (P4 spec)

For more information, please see [p4.org](http://p4.org)

## How to install:

```bash
$ curl -o- -L https://raw.githubusercontent.com/TakeshiTseng/vim-language-p4/master/install.sh | bash
```

## License

MIT
